﻿importPackage(Packages.scripting.newscripting)
importPackage(Packages.constants)

h = "#fUI/UIMiniGame.img/starPlanetRPS/heart#";
g = "#fMap/MapHelper.img/minimap/anothertrader#";
a = "#i3801317#"
    b = "#i3801313#"
    c = "#i3801314#"
    d = "#i3801315#"
    p = "#fc0xFFF781D8#"

    보라 = "#fMap/MapHelper.img/weather/starPlanet/7#";
파랑 = "#fMap/MapHelper.img/weather/starPlanet/8#";
별파 = "#fUI/GuildMark.img/Mark/Pattern/00004001/11#"
    별노 = "#fUI/GuildMark.img/Mark/Pattern/00004001/3#"
    별흰 = "#fUI/GuildMark.img/Mark/Pattern/00004001/15#"
    별갈 = "#fUI/GuildMark.img/Mark/Pattern/00004001/5#"
    별빨 = "#fUI/GuildMark.img/Mark/Pattern/00004001/1#"
    별검 = "#fUI/GuildMark.img/Mark/Pattern/00004001/16#"
    별보 = "#fUI/GuildMark.img/Mark/Pattern/00004001/13#"
    별 = "#fUI/FarmUI.img/objectStatus/star/whole#"
    S = "#fUI/CashShop.img/CSEffect/today/0#"
    보상 = "#fUI/UIWindow2.img/Quest/quest_info/summary_icon/reward#"
    획득 = "#fUI/UIWindow2.img/QuestIcon/4/0#"
    색 = "#fc0xFF6600CC#"
    엔터 = "\r\n"
    엔터2 = "\r\n\r\n"

    mTown = ["SixPath", "Henesys", "Ellinia", "Perion", "KerningCity",
        "Rith", "Dungeon", "Nautilus", "Ereb", "Rien",
        "Orbis", "ElNath", "Ludibrium", "Folkvillige", "AquaRoad",
        "Leafre", "Murueng", "WhiteHerb", "Ariant", "Magatia",
        "Edelstein", "Eurel", "critias", "Haven", "Road of Vanishing", "ChewChew", "Lacheln", "Arcana", "Morass", "esfera", "aliance", "moonBridge", "TheLabyrinthOfSuffering", "Limen"];

cTown = [104020000, 120040000, 101000000, 102000000, 103000000,
    104000000, 105000000, 120000000, 130000000, 140000000,
    200000000, 211000000, 220000000, 224000000, 230000000,
    240000000, 250000000, 251000000, 260000000, 261000000,
    310000000, 101050000, 241000000, 310070000, 450001000, 450002000, 450003000, 450005000, 450006130, 450007040, 450009050, 450009100, 450011500, 450012300];

var status = -1;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
        return;
    }
    if (mode == 0) {
        status--;
    }
    if (mode == 1) {
        status++;
    }

    if (status == 0) {
        var count = 1;
        // 최대 횟수
        count += cm.getPlayer().getBossTier();
        var msg = "#fs11#";
/*
        if (cm.getPlayer().isGM()) {
            msg += "#fc0xFF000000##e[#e#rEVENT#k#l]\r\n";
            msg += "#L30##fc0xFF6799FF#" + 별보 + " | 텐구#l　　";
            msg += "#L31##fc0xFF6799FF#" + 별보 + " | 아케치 미츠히데#l\r\n\r\n";
        }
*/

        msg += "#fc0xFF000000#※ 보스이동은 파티장만 가능합니다\r\n\r\n";
        msg += "#fc0xFF000000##e#dEASY#k#l = " + 별노 + "　　#bNOMARL#k = " + 별파 + "　　#rHARD#k = " + 별빨 + "\r\n";
        msg += "#L1##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.ChaosZakum, "eNum") + "/" + count + "]#d" + 별노 + " | 자쿰#l　";
        // msg += "#L2##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234569, "zakum_clear") + "/" + count + "]#d" + 별노 + " | 카웅#l\r\n";
        msg += "#L3##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.Horntail, "clear") + "/" + count + "]#d" + 별노 + " | 혼테일#l\r\n";
        //msg += "#L4##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.Hillah, "eNum") + "/" + count + "]#d" + 별노 + " | 힐라#l";
        msg += "#L5##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234571, "vonleon_clear") + "/" + count + "]#d" + 별노 + " | 반레온#l";
        msg += "#L6##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234570, "akairum_clear") + "/" + count + "]#d" + 별노 + " | 아카이럼#l\r\n";
        msg += "#L7##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234569, "pinkbean_clear") + "/" + count + "]#d" + 별노 + " | 핑크빈#l";
        msg += "#L8##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.Cygnus, "eNum") + "/" + count + "]#d" + 별노 + " | 시그너스#l#k\r\n\r\n";

        msg += "#L9##fc0xFF6799FF#["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.Magnus, "eNum") + "/" + count + "]["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.HardMagnus, "eNum") + "/" + count + "]#d" + 별파 + " | 매그너스#l";
        msg += "#L11##fc0xFF6799FF#["+cm.getPlayer().getOneInfoQuestInteger(1234569, "papulatus_clear")  + "/" + count + "]["+cm.getPlayer().getOneInfoQuestInteger(1234569, "chaos_papulatus_clear")  + "/" + count + "]#d" + 별파 + " | 파풀라투스#k#l\r\n";
        msg += "#L10##fc0xFF6799FF#["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.CrimsonQueen, "eNum") + "/" + count + "]["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.ChaosCrimsonQueen, "eNum") + "/" + count + "]#d" + 별파 + " | 블러디퀸#l";
        msg += "#L10##fc0xFF6799FF#["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.Pierre, "eNum") + "/" + count + "]["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.ChaosPierre, "eNum") + "/" + count + "]#d" + 별파 + " | 피에르#l\r\n";
        msg += "#L10##fc0xFF6799FF#["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.VonBon, "eNum") + "/" + count + "]["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.ChaosVonBon, "eNum") + "/" + count + "]#d" + 별파 + " | 반반#l　　";
        msg += "#L10##fc0xFF6799FF#["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.Vellum, "eNum") + "/" + count + "]["+cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.ChaosVellum, "eNum") + "/" + count + "]#d" + 별파 + " | 벨룸#l\r\n\r\n";

        msg += "#L12##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234570, "swoo_clear") + "/" + count + "][" + cm.getPlayer().getOneInfoQuestInteger(1234569, "swoo_clear") + "/" + count + "]#d" + 별빨 + " | 스우#l　　";
        msg += "#L13##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234570, "demian_clear") + "/" + count + "][" + cm.getPlayer().getOneInfoQuestInteger(1234569, "demian_clear") + "/" + count + "]#d" + 별빨 + " | 데미안#l\r\n";
        msg += "#L14##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234570, "lucid_clear") + "/" + count + "][" + cm.getPlayer().getOneInfoQuestInteger(1234569, "lucid_clear") + "/" + count + "]#d" + 별빨 + " | 루시드#l　";
        msg += "#L15##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234570, "will_clear") + "/" + count + "][" + cm.getPlayer().getOneInfoQuestInteger(1234569, "will_clear") + "/" + count + "]#d" + 별빨 + " | 윌#l\r\n";
        //msg += "#L16##fc0xFF6799FF#[" + cm.getPlayer().getKeyValue("Normal_FireWolf") +"/" + count +"]#d | "+별빨+" | 불꽃늑대#l\r\n";
        //msg += "#L17##fc0xFF6799FF#[" + cm.getPlayer().getKeyValue("URS") +"/" + count +"]#d | "+별빨+" | 우르스#l";
        msg += "#L19##fc0xFF6799FF#[0/0][" + cm.getPlayer().getOneInfoQuestInteger(1234589, "dunkel_clear") + "/" + count + "]#d" + 별빨 + " | 듄켈#l　　";
        msg += "#L20##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234590, "dusk_clear") + "/" + count + "][" + cm.getPlayer().getOneInfoQuestInteger(1234589, "dusk_clear") + "/" + count + "]#d" + 별빨 + " | 더스크#l\r\n\r\n";
        //msg += "#L23##fc0xFF6799FF#[0/0][" + cm.getPlayer().getOneInfoQuestInteger(1234569, "guardian_angel_slime_clear") + "/" + count + "]#d" + 별빨 + " | 가디언 엔젤 슬라임#l\r\n\r\n";

        msg += "　　　#L18##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234569, "jinhillah_clear") + "/" + count + "]#d" + 별검 + " | 고통의 미궁 : 진 힐라#l\r\n";
        msg += "　　　#L21##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(1234570, "blackmage_clear") + "/" + count + "]#d" + 별검 + " | 초월자 : 검은마법사#l\r\n";
        msg += "　　　#L22##fc0xFF6799FF#[" + cm.getPlayer().getOneInfoQuestInteger(BossQuestConstants.SerniumSeren, "clear") + "/" + count + "]#d" + 별검 + " | 선택받은 세렌#l\r\n ";
        cm.sendSimpleS(msg, 4);
    } else if (status == 1) {
        ans_01 = selection;
        if (ans_01 != 16 && ans_01 != 30 && ans_01 != 31) {
            if (cm.getPlayer().getEventInstance() != null) { // @보스 쳐놓고 보스 입장 시 문제 방지
                return;
            }
            if (!cm.isLeader()) {
                cm.sendNext("파티장만 이용할 수 있습니다.");
                return;
            }
        }
        switch (ans_01) {
        case 2:
            cm.dispose();
            cm.warpParty(221030900, 0);
            return;
        case 1:
            cm.dispose();
            cm.warpParty(211042300, 0);
            return;

        case 3:
            cm.sendNext("현재 점검중입니다.");
            cm.dispose();
            //cm.warpParty(240050000, 0);
            return;

        case 4:
            cm.dispose();
            cm.warpParty(262000000, 0);
            return;

        case 5:
            cm.dispose();
            cm.warpParty(211070000, 0);
            return;

        case 6:
            cm.dispose();
            cm.warpParty(272020110, 0);
            return;

        case 7:
            cm.dispose();
            cm.warpParty(270050000, 0);
            return;

        case 8:
            cm.dispose();
            cm.warpParty(271041000, 0);
            return;

        case 9:
            cm.dispose();
            cm.warpParty(401060000, 0);
            return;

        case 10:
            cm.dispose();
            cm.warpParty(105200000, 0);
            return;

        case 11:
            cm.dispose();
            cm.warpParty(220080000, 0);
            return;

        case 12:
            cm.dispose();
            cm.warpParty(350060300, 0);
            return;

        case 13:
            cm.dispose();
            cm.warpParty(105300303, 0);
            return;

        case 14:
            cm.dispose();
            cm.warpParty(450004000, 0);
            return;

        case 15:
            cm.dispose();
            cm.warpParty(450007240, 0);
            return;

        case 16:
            cm.dispose();
            cm.openNpc(9120012);
            return;

        case 17:
            cm.dispose();
            cm.warpParty(970072200, 0);
            return;

        case 18:
            cm.dispose();
            cm.warpParty(940500100, 0);
            return;

        case 19:
            cm.dispose();
            cm.warpParty(450012200, 0);
            return;

        case 20:
            cm.dispose();
            cm.warpParty(450009301, 0);
            return;

        case 21:
            cm.dispose();
            cm.warpParty(450012500, 0);
            return;

        case 22:
            cm.dispose();
            cm.warpParty(410000670, 0);
            return;
        case 23:
            cm.dispose();
            cm.warpParty(160000000, 0);
            return;
        case 30:
            cm.dispose();
            ScriptManager.runScript(cm.getClient(), "tengu_enter", null);
            return;
        case 31:
            cm.dispose();
            ScriptManager.runScript(cm.getClient(), "mitsuhide_enter", null);
            return;
        }
    }
}
