﻿package constants;

public enum TempKeyValueConstants {
}
