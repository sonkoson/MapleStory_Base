﻿package constants;

public class Locales {
   public static String getKoreanJosa(String text, JosaType type) {
      // Korean grammatical particle logic removed as we are translating to English.
      return "";
   }
}
