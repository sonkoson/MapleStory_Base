﻿package constants;

public class MapConstants {
   public static boolean isStartingEventMap(int mapid) {
      switch (mapid) {
         case 109010000:
         case 109020001:
         case 109030001:
         case 109030101:
         case 109030201:
         case 109030301:
         case 109030401:
         case 109040000:
         case 109060001:
         case 109060002:
         case 109060003:
         case 109060004:
         case 109060005:
         case 109060006:
         case 109080000:
         case 109080001:
         case 109080002:
         case 109080003:
            return true;
         default:
            return false;
      }
   }

   public static boolean isEventMap(int mapid) {
      return mapid >= 109010000 && mapid < 109050000 || mapid > 109050001 && mapid < 109090000 || mapid >= 809040000 && mapid <= 809040100;
   }

   public static boolean isCoconutMap(int mapid) {
      return mapid == 109080000
         || mapid == 109080001
         || mapid == 109080002
         || mapid == 109080003
         || mapid == 109080010
         || mapid == 109080011
         || mapid == 109080012
         || mapid == 109090301
         || mapid == 109090302
         || mapid == 109090303
         || mapid == 109090304
         || mapid == 910040100;
   }
}
