package objects.fields.child.minigame.battlereverse;

public class ChipType {
   public static final byte None = -1;
   public static final byte Team0 = 0;
   public static final byte Team1 = 1;
   public static final byte Blocked = 3;
}
