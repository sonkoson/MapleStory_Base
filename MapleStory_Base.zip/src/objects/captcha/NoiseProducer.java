package objects.captcha;

import java.awt.image.BufferedImage;

public interface NoiseProducer {
   void makeNoise(BufferedImage var1);
}
