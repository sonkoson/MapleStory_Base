package objects.captcha;

import java.awt.image.BufferedImage;

public interface GimpyRenderer {
   void gimp(BufferedImage var1);
}
