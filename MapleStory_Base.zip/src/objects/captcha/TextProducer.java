package objects.captcha;

public interface TextProducer {
   String getText();
}
