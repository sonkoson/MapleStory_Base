package objects.captcha;

import java.awt.image.BufferedImage;

public interface WordRenderer {
   void render(String var1, BufferedImage var2);
}
