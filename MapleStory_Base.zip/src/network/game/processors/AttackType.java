package network.game.processors;

public enum AttackType {
   NON_RANGED,
   RANGED,
   RANGED_WITH_SHADOWPARTNER,
   NON_RANGED_WITH_MIRROR,
   MAGIC;
}
