package network;

public interface ShutdownServerMBean extends Runnable {
   void shutdown();
}
