package network.netty;

public enum ServerType {
   LOGIN,
   GAME,
   SHOP,
   AUCTION;
}
