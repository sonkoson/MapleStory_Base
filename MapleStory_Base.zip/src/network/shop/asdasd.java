package network.shop;

public class asdasd {
   public static void main(String[] args) {
      System.out.println(System.currentTimeMillis());
   }
}
