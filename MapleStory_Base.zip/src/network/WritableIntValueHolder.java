package network;

public interface WritableIntValueHolder {
   short getValue();

   void setValue(short var1);
}
