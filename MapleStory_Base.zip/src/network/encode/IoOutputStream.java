package network.encode;

public interface IoOutputStream {
   void writeByte(byte var1);
}
