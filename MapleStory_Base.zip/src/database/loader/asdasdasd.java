﻿package database.loader;

public class asdasdasd {
   public static void main(String[] args) {
      int itemID = 1052367;
      int a = itemID / 1000;
      System.out.println(a % 10);
   }
}
